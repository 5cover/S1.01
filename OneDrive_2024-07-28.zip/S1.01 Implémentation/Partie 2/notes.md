# Notes sudoku

On ne peut pas modifier une valeur entrée.
