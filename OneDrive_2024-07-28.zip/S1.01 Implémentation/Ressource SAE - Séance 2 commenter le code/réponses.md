# Ressource 2 S1.01

## 1

Incompréhensible

## 2

Que fait ce programme?

Ce programme implemente les chaines de caracteres par des listes chainees dynamiques et propose plusieurs fonctions de manipulation de chaines

typetab - un tableau de caracteres est utilise temporairement pour ordonner les caracteres d'une chaine

TMAX - Taille Maximum d'une chaine quand on veut ordonner ses caracteres

ide - retourne un booléen indiquant si deux chaines sont identique

N != la fonction LVT doit avoir réussi à copier la chaîne dans le tableau temporaire, et donc ne pas avoir retourné -1. Si -1 est retourné, cela signifie que la chaîne est plus longue que TMAX.

Inconvénient de ana - la fonction ana retourne un booléen indiquant si deux chaînes sont des anagrammes.
Elle modifie la chaîne passée en second paramètre, ce qui n'est pas le comportement attendu dans ce type de fonction.